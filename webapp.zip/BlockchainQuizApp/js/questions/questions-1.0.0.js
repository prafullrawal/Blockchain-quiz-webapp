questionData = [
    {
        question: 'Blockchain is:',
        answers: [
            { id: 0, answer: 'A record keeping system.' },
            { id: 2, answer: 'An event tracking system.' },
            { id: 3, answer: 'A workflow platform. ' },
            { id: 4, answer: 'All of the above ' },
            { id: 5, answer: 'a and b' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Double-entry accounting is:',
        answers: [
            { id: 0, answer: 'A method for tracking information ' },
            { id: 1, answer: 'A record for tracking debits and credits ' },
            { id: 2, answer: 'A record for tracking debits, credits, and an immutable link to all past debits and credits ' },
            { id: 3, answer: 'The ledger for an investor’s portfolio that includes the current price of their investment ' }
            
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Select which statement is true about Blockchain: ',
        answers: [
            { id: 0, answer: 'Changing the data on any block will result in a different hash ' },
            { id: 1, answer: 'A block is made up of 25 lines or records' },
            { id: 2, answer: 'Chain refers to the program that physically links blocks together' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Group Consensus is reached when how many members agree?',
        answers: [
            { id: 0, answer: '10% ' },
            { id: 1, answer: '51% or more' },
            { id: 2, answer: '49% or more' },
            { id: 3, answer: '100%' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Which of the following is a type of Blockchain transaction? ',
        answers: [
            { id: 0, answer: 'Two or more parties, exchange of monetary value such as cryptocurrency. ' },
            { id: 1, answer: 'Two or more parties, but no exchange of monetary value such as updates to medical records. ' },
            { id: 2, answer: 'One party announcing an important event such as supply chain management, business process automation, creation/auditing of financial records. ' },
            { id: 3, answer: 'All of the above are a type of Blockchain transaction.' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'Blocks in Blockchain are “chained” together by:  ',
        answers: [
            { id: 0, answer: 'Adding a pointer in the ledger to the previous block. ' },
            { id: 1, answer: 'By taking a picture of the block being added with the block behind it. ' },
            { id: 2, answer: 'By embedding the genesis block into the header of the new block. ' },
            { id: 3, answer: 'By hashing the previous block and embedding that hash into the new block’s header' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'A decentralized ledger acts as a trust broker, like a bank ?',
        answers: [
            { id: 0, answer: 'True ' },
            { id: 1, answer: 'False' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Blockchain was documented and released via a whitepaper by:',
        answers: [
            { id: 0, answer: 'Bill Gates ' },
            { id: 1, answer: 'Satoshi Takamoto  ' },
            { id: 2, answer: 'Larry Ellison  ' },
            { id: 3, answer: 'Satoshi Nakamoto' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'Blockchain is the same thing as Bitcoin ?',
        answers: [
            { id: 0, answer: 'True ' },
            { id: 1, answer: 'False' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Blockchain provides the same services as a traditional bank, except for:',
        answers: [
            { id: 0, answer: 'Taking deposits and issuing credits ' },
            { id: 1, answer: 'Acting as a trust broker in exchanges ' },
            { id: 2, answer: 'Decoupling possession and ownership ' },
            { id: 3, answer: 'Providing Certificates of Deposit ' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'Hyperledger and Ethereum both went live in which year? ',
        answers: [
            { id: 0, answer: '2008 ' },
            { id: 1, answer: '2009 ' },
            { id: 2, answer: '2015 ' },
            { id: 3, answer: '2012 ' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'What is not a benefit of Blockchain? ',
        answers: [
            { id: 0, answer: 'Trust ' },
            { id: 1, answer: 'Security ' },
            { id: 2, answer: 'Decentralization ' },
            { id: 3, answer: 'The Urkel Tree ' },
            { id: 4, answer: 'Immutability' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'In Proof of Work consensus what happens when you add another node to the network? ',
        answers: [
            { id: 0, answer: 'Security time is increased by 1/N and transaction time is increased by 1/N where N equals the number of nodes on network ' },
            { id: 1, answer: 'Security time is increased by 1/N and transaction time is decreased by 1/N where N equals the number of nodes on network ' },
            { id: 2, answer: 'Security time is decreased by 1/N and transaction time is increased by 1/N where N equals the number of nodes on network ' },
            { id: 4, answer: 'Security time is decreased by 1/N and transaction time is decreased by 1/N where N equals the number of nodes on network  ' },
             { id: 5, answer: 'None of the above  ' }
            
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'The Private Key does what? ',
        answers: [
            { id: 0, answer: 'Used to verify the digital signature of a given key pair ' },
            { id: 1, answer: 'Used to create a one-way encoded hash of a block of data ' },
            { id: 2, answer: 'Used to sign any transaction that might be made by the holder of the key pair ' },
            { id: 3, answer: 'Used to confirm the identity of an application ' },
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'Cryptographic hashing is a one-way function that encrypts information that can be decrypted.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Proof of Stake consensus costs less, is faster and more secure than Proof of Stake because of the use of a “nonce”. ',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'A hard fork occurs when: ',
        answers: [
            { id: 0, answer: 'New Blockchain software is released which breaks or modifies existing rules. ' },
            { id: 1, answer: 'Some nodes decide to keep a different version of the ledger then others ' },
            { id: 2, answer: 'A & B ' },
            { id: 3, answer: 'Node hardware is updated to newer models ' },
            { id: 4, answer: 'None of the above ' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'On a public Blockchain such as Ethereum, transactions are validated before they are added to the block. ',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'The Merkle Tree serves which important function in Blockchain? ',
        answers: [
            { id: 0, answer: 'It acts as an index, allowing transactions to be found quickly regardless of their location on the Blockchain ' },
            { id: 1, answer: '. It reduces the overall size of the Blockchain ' },
            { id: 2, answer: 'It increases speed in Proof of Work consensus ' },
            { id: 3, answer: 'All of the Above ' },
            { id: 4, answer: 'None of the Above' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'All of the following are key terms in Cryptography except: ',
        answers: [
            { id: 0, answer: 'The Secret' },
            { id: 1, answer: 'The Function' },
            { id: 2, answer: 'The Root Hash ' },
            { id: 3, answer: 'The Cypher ' },
            { id: 4, answer: 'The Key' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Public Blockchains like Ethereum can only store financial information. ',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'A public closed Block chain allows which of the following? ',
        answers: [
            { id: 0, answer: 'Many people can write, only a few can read ' },
            { id: 1, answer: 'Many people can read and write data ' },
            { id: 2, answer: 'Only a few people can write data, many can read ' },
            { id: 3, answer: 'All of the above ' },
            { id: 4, answer: 'None of the above' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Block less platforms offer which advantage? ',
        answers: [
            { id: 0, answer: 'Lower cost ' },
            { id: 1, answer: 'Greater transaction processing capacity  ' },
            { id: 2, answer: 'Guaranteed smaller network size  ' },
            { id: 3, answer: 'Greater storage space on the ledger' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Each block in a Block chain is linked to what? ',
        answers: [
            { id: 0, answer: 'The block that occurred after it ' },
            { id: 1, answer: 'The preceeding block ' },
            { id: 2, answer: 'The first block ' },
            { id: 3, answer: 'The current block' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Users must explicitly purchase gas before using a Blockchain solution ',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'The ERC20 standard defines ',
        answers: [
            { id: 0, answer: 'A consensus mechanism ' },
            { id: 1, answer: 'How hard forks are managed ' },
            { id: 2, answer: 'A coin / token standard ' },
            { id: 3, answer: 'None of the above' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: '. Which of the following is not one of the three main Ethereum token standards? ',
        answers: [
            { id: 0, answer: 'ERC20  ' },
            { id: 1, answer: 'ERC223 ' },
            { id: 2, answer: 'ERC508 ' },
            { id: 3, answer: 'ERC721' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'A private / open Blockchain would be a good choice for situations where only a few people should be able to write data, but a large number of people should be able to consume that data. ',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Which of the following is an example for a blockless platform? ',
        answers: [
            { id: 0, answer: 'IoTA   ' },
            { id: 1, answer: 'Swarm  ' },
            { id: 2, answer: 'Ripple  ' },
            { id: 3, answer: 'Litecoin' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'If a function call runs out of gas, the gas submitted by the user is returned and the function rolls-back ',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'If a function call runs out of gas, the gas submitted by the user is returned and the function rolls-back ',
        answers: [
            { id: 0, answer: 'ERC20'},
            { id: 1, answer: 'ERC721'},
            { id: 2, answer: 'ERC508'},
            { id: 3, answer: 'ERC1014'}

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'An open Blockchain architecture should be used in cases where public verification is important. ',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' },
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Blockchain Smart Contracts are analogous to: ',
        answers: [
            { id: 0, answer: 'Software ' },
            { id: 1, answer: 'Firmware ' },
            { id: 2, answer: 'Natural Language contracts  ' },
            { id: 3, answer: 'C++ solutions ' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Databases provide greater fault-tolerance than public Blockchain networks.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Public Blockchains are ideal solutions when data sovereignty is a concern.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Which of the following is true of Smart Contracts?',
        answers: [
            { id: 0, answer: 'They must be less than 100kB in size' },
            { id: 1, answer: 'They are written in English' },
            { id: 2, answer: 'They are translated to hex format when compiled' },
            { id: 3, answer: 'They exist as permanent records on the Blockchain once deployed' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'Just like conventional networks, Peer-to-Peer networks contain both clients and servers.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Blockchain will be a better fit over a traditional database system when:',
        answers: [
            { id: 0, answer: 'Public validation is required ' },
            { id: 1, answer: 'Infinite scalability is needed' },
            { id: 2, answer: 'No single authority can or should own the data' },
            { id: 3, answer: 'All of the above' },
            { id: 4, answer: 'None of the above' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'When a Smart Contract is killed it…',
        answers: [
            { id: 0, answer: 'No longer accepts new transactions but remains on the Blockchain forever' },
            { id: 1, answer: 'Is removed from the Blockchain completely' },
            { id: 2, answer: 'Is removed from the Blockchain and replaced with a “bookmark” or pointer' },
            { id: 3, answer: 'Is moved to the test Blockchain network for historical purposes' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'IPFS stands for:',
        answers: [
            { id: 0, answer: 'Internet Protocol File System' },
            { id: 1, answer: 'Inter Planetary File System' },
            { id: 2, answer: 'Inner Planetary File System' },
            { id: 3, answer: 'Internet Public File System' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Hypermedia Distributed File System is …',
        answers: [
            { id: 0, answer: 'A mesh network' },
            { id: 1, answer: 'A multimedia content distribution system' },
            { id: 2, answer: 'A content-based addressing system' },
            { id: 3, answer: 'A content delivery network' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'What is NOT a primary network architecture?',
        answers: [
            { id: 0, answer: 'Decentralized' },
            { id: 1, answer: 'Meshed Filenet' },
            { id: 2, answer: 'Distributed' },
            { id: 3, answer: 'Centralized' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Blockchains support CRUD operations, just a like a database.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'DApp stands for',
        answers: [
            { id: 0, answer: 'Decentralized Application' },
            { id: 1, answer: 'Directed Acyclic Parity Principle' },
            { id: 2, answer: 'Direct Autonomous Purchasing Power' },
            { id: 3, answer: 'Downstream Application of Powerful Provisions' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Remix is a browser-based IDE for editing Smart Contracts on which platform?',
        answers: [
            { id: 0, answer: 'Bitcoin' },
            { id: 1, answer: 'Monero' },
            { id: 2, answer: 'Hyperledger' },
            { id: 3, answer: 'Ethereum' }
            
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'By default, Smart Contracts cannot access data outside the Blockchain.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Developing a user interface for a public Blockchain application requires developers to learn new skills.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'The middle layer in a Blockchain application contains the user interface.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'What are the two types of transactions in the Hyperledger Fabric?',
        answers: [
            { id: 0, answer: 'Deploy and Intake' },
            { id: 1, answer: 'Deploy and Invoke' },
            { id: 2, answer: 'Publish and Call' },
            { id: 3, answer: 'Copy and Evoke' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'To develop in Hyperledger, you use the following tool:',
        answers: [
            { id: 0, answer: 'Solidity' },
            { id: 1, answer: 'Remix' },
            { id: 2, answer: 'Composer' },
            { id: 3, answer: 'Eclipse' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'DAO stands for:',
        answers: [
            { id: 0, answer: 'Decoupled Application Overture' },
            { id: 1, answer: 'Decentralized Autonomous Organization' },
            { id: 2, answer: 'Distributed Autonomous Organization' },
            { id: 3, answer: 'Decentralized Autonomous Offer' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'IDE is short for:',
        answers: [
            { id: 0, answer: 'Independent Development Environment' },
            { id: 1, answer: 'Integrated Design Environment' },
            { id: 2, answer: 'Independent Design Environment' },
            { id: 3, answer: 'Integrated Development Environment' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'Smart Contracts by default have no access to external data. To overcome this, you can use a/an _____________.',
        answers: [
            { id: 0, answer: 'API' },
            { id: 1, answer: 'Web Service' },
            { id: 2, answer: 'REST Endpoint' },
            { id: 3, answer: 'Oracle' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3   
    },
    {
        question: 'Other tools and frameworks to be familiar with when building Blockchain applications include:',
        answers: [
            { id: 0, answer: 'Ganache' },
            { id: 1, answer: 'Truffle' },
            { id: 3, answer: 'Web3.js' },
            { id: 4, answer: 'a, b and c' },
            { id: 5, answer: 'Souffle' },
            { id: 6, answer: 'a,e' },
            { id: 7, answer: 'All of the above' },
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 4
    },
    {
        question: 'When developing Blockchain applications which of the following is NOT used?',
        answers: [
            { id: 0, answer: 'HTML' },
            { id: 1, answer: 'JavaScript' },
            { id: 2, answer: 'NodeJS' },
            { id: 3, answer: 'J#' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
        {
        question: 'Guiding Principles can be violated if a sufficient business reason exists.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'A good solution can and often does incorporate Blockchain along with more conventional technologies.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Which of the following design artifacts describes what a solution should do without focusing on how it should be done?',
        answers: [
            { id: 0, answer: 'Tasks' },
            { id: 1, answer: 'Technical Requirements' },
            { id: 2, answer: 'Personas' },
            { id: 3, answer: 'Functional Requirements' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'Which of the following is true regarding a contracts Kill function?',
        answers: [
            { id: 0, answer: 'Security is provided for this method by the platform, no additional concerns exist' },
            { id: 1, answer: 'A killed contract can be revived' },
            { id: 2, answer: 'Funds can be extracted from a killed contract' },
            { id: 3, answer: 'None of the above' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'Guiding Principles will be the same for every type of Blockchain solution.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'A user can have multiple personas.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'User stories will help to create:',
        answers: [
            { id: 0, answer: 'Guiding Principles' },
            { id: 1, answer: 'Technical Requirements' },
            { id: 2, answer: 'Functional Requirements' },
            { id: 3, answer: 'Use Cases' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: '. Which of the following design artifacts describes how a functional requirement will be fulfilled? ',
        answers: [
            { id: 0, answer: 'Task' },
            { id: 1, answer: 'Persona' },
            { id: 2, answer: 'Guiding Principle' },
            { id: 3, answer: 'Technical Requirement' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'What are the base columns you should have in your Task estimation worksheet?',
        answers: [
            { id: 0, answer: 'Task Name' },
            { id: 1, answer: 'Task Owner' },
            { id: 2, answer: 'Estimated Time to Complete' },
            { id: 3, answer: 'Skillset Required/Role' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'What is NOT a Blockchain architecture fundamental question?',
        answers: [
            { id: 0, answer: 'Does the use of Blockchain create a better end-user experience?' },
            { id: 1, answer: 'Do you need a solution ready for heavy use on day 1?' },
            { id: 2, answer: 'Who needs to see the data? Who should NOT see the data?' },
            { id: 3, answer: 'What color would you like your help icon be for your end users UI?' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'To maximize efficiency, a project team should be as large as possible.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Public Blockchains offer lower transaction speed than private Blockchains',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
        {
        question: 'According to the Sandwich Complexity Model, the bulk of the application logic should live at which layer?',
        answers: [
            { id: 0, answer: 'The validation nodes' },
            { id: 1, answer: 'The middle layer' },
            { id: 2, answer: 'The User Interface' },
            { id: 3, answer: 'Functional Requirements' },
            { id: 4, answer: 'None of the above' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Unless the technology decisions are made up-front, it is hard to design a good Blockchain solution.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'A modular design pattern for Smart Contracts is generally preferable unless which feature is desired?',
        answers: [
            { id: 0, answer: 'Security' },
            { id: 1, answer: 'Scalability' },
            { id: 2, answer: 'Simplicity' },
            { id: 3, answer: 'None of the above' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Push payments are the desired pattern for giving funds to a user.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'An Agile development methodology is desirable post-release.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'What are some of the best practices for testing a Blockchain application?',
        answers: [
            { id: 0, answer: 'Always go from local testing, to a test network and then to production network.' },
            { id: 1, answer: 'Use a local Blockchain tool like Ganache when doing development and initial testing.' },
            { id: 2, answer: 'Both a and b' },
            { id: 3, answer: 'None of the above' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'When developing a Blockchain application always align _____________ to your guiding principles.',
        answers: [
            { id: 0, answer: 'Users' },
            { id: 1, answer: 'Trouble tickets' },
            { id: 2, answer: 'Personas' },
            { id: 3, answer: 'Infrastructure' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'What is the risk of using a Monolithic architecture for an application or Smart Contract?',
        answers: [
            { id: 0, answer: 'It provides reusable code' },
            { id: 1, answer: 'There is a single attack surface or single point of failure' },
            { id: 2, answer: 'In introduces additional security attack surfaces' },
            { id: 3, answer: 'There are no risks to a Monolithic architecture' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'All Smart Contract function calls should be wrapped in a:',
        answers: [
            { id: 0, answer: 'Try / Catch statement' },
            { id: 1, answer: 'A Contract declaration' },
            { id: 2, answer: 'A For statement' },
            { id: 3, answer: 'A ForEach Statement' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'If a 3rd party contract has never been hacked, it is safe to trust.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'Data on a public Blockchain is automatically encrypted.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Which of the following is an Ethereum test network?',
        answers: [
            { id: 0, answer: 'Franklin' },
            { id: 1, answer: 'Ropey' },
            { id: 2, answer: 'Ropsten' },
            { id: 3, answer: 'Zoe' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
        {
        question: 'All of the following are types of bugs except:',
        answers: [
            { id: 0, answer: 'Business Logic' },
            { id: 1, answer: 'Security' },
            { id: 2, answer: 'Integration' },
            { id: 3, answer: 'Contract Size' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'TDD refers to:',
        answers: [
            { id: 0, answer: 'Taking Down Data' },
            { id: 1, answer: 'Test Driven Development' },
            { id: 2, answer: 'Testing During Development' },
            { id: 3, answer: 'Testing Direct Duration' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Multimedia bug reports add little value relative to their cost.',
        answers: [
            { id: 0, answer: 'TRUE' },
            { id: 1, answer: 'FALSE' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Traditional testing time should be scaled up how much in the Blockchain world?',
        answers: [
            { id: 0, answer: '2x' },
            { id: 1, answer: '5x – 10x' },
            { id: 2, answer: '20x' },
            { id: 3, answer: '100x' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Testing tools lead to better test cases.',
        answers: [
            { id: 0, answer: 'True' },
            { id: 1, answer: 'False' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    },
    {
        question: 'Shift-Left Testing is…',
        answers: [
            { id: 0, answer: 'Where your developers test their own code before deploying it to the next environment. ' },
            { id: 1, answer: 'Involving your testers later in the project lifecycle.' },
            { id: 2, answer: 'Involving your testers earlier in the project lifecycle.' },
            { id: 3, answer: 'Where your developers write the test cases and your testers test them.' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'Which of the following is NOT a type of testing?',
        answers: [
            { id: 0, answer: 'Evolution' },
            { id: 1, answer: 'Unit' },
            { id: 2, answer: 'Configuration' },
            { id: 3, answer: 'Stress' },
            { id: 4, answer: 'Regression' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: '______________ should be the start of your test cases.',
        answers: [
            { id: 0, answer: 'Technical Requirements'},
            { id: 1, answer: 'Actors' },
            { id: 2, answer: 'Personas' },
            { id: 3, answer: 'User stories' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'What is the ideal but not realistic target for test coverage of a Blockchain application?',
        answers: [
            { id: 0, answer: '100%' },
            { id: 1, answer: '92%' },
            { id: 2, answer: '85%' },
            { id: 3, answer: 'None of the above' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 0
    },
    {
        question: 'What is a bug bounty?',
        answers: [
            { id: 0, answer: 'Hiring an outside expert to review and update your Blockchain architecture and code.' },
            { id: 1, answer: 'Offering a non-fungible token to someone who writes up all of the risks to your code.' },
            { id: 2, answer: 'Posting a notice to a community that hacking is not allowed on your code.' },
            { id: 3, answer: 'Offering a reward to others who find flaws, security holes or exploits in your code.' }
        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 3
    },
    {
        question: 'What is NOT a Blockchain Testing best practice?',
        answers: [
            { id: 0, answer: 'Separate your development and test environments' },
            { id: 1, answer: 'Test a function multiple times from the point of view of multiple users' },
            { id: 2, answer: 'Only create support materials if you are using a public Blockchain' },
            { id: 3, answer: 'Explicitly state any untested platforms that are not supported by your Blockchain application.' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 2
    },
    {
        question: 'Blockchain developers should test their own code before publishing it to production?',
        answers: [
            { id: 0, answer: 'TRUE' },
            { id: 1, answer: 'FALSE' }

        ],
        currentAnswer: ko.observable(-2),
        correctAnswer: 1
    }

];